<?php
/**
 * @package scoremasters
 */

namespace Scoremasters\Inc\Services;


class CalculatePlayerPosition {
    //get all players 
    // calculate position in every championship
    // save position
}