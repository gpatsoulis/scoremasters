<?php
/**
 * @package scoremasters
 */

namespace Scoremasters\Inc\Classes;

class Fixture {

    public $fixture;

    public function __construct (WP_POST $scm_fixture){
        
    }

}


function set_active_fixture(){

}