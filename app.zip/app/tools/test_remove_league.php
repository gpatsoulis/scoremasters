<?php
use Scoremasters\Inc\Base\ScmData;

//var_dump(ScmData::get_all_fixtures_for_season());

//SELECT * FROM `wp_usermeta` where user_id = 2 and meta_key = 'scm_league_status'
//var_dump(remove_user_meta(2,843));
//var_dump(remove_from_league($melagouri,2));
